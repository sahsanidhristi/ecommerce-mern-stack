import React from 'react'

import "./AboutPage.css";
import image_6 from "../../images/pic-6.jpeg";
import workimg_7 from "../../images/workimg7.jpeg";
import workcult from "../../images/workplace.jpeg";
import workimg_5 from "../../images/workimg5.jpg";
import workimg_2 from "../../images/workimg2.png";
import workimg from "../../images/workimg.jpg";
import workimg_3 from "../../images/workimg3.jpg";
import image_2 from "../../images/pic-2.png";
import image_1 from "../../images/young-male-entrepreneur-making-eye-contact-against-blue-background.jpg";
import image_3 from "../../images/young-handsome-business-man-choosing-car-car-showroom.jpg";
import image_4 from "../../images/smiley-businesswoman-posing-outdoors-with-arms-crossed-copy-space.jpg";
import image_5 from "../../images/pic-5.jpg";
import blog_2 from "../../images/blog2.jpg";
import company from "../../images/company.jpeg";
import blog_3 from "../../images/blog3.png";
export default function AboutPage() {
  return (
    <>
    <section className="company">
      <div className="clearfix">
        <div className="content">
          <div className="company-header">
            <h2 className="company-title">who we are?</h2>
          </div>
          <p>
            Our journey began with a simple yet ambitious goal: to provide
            customers with a curated selection of high-quality products,
            unparalleled customer service, and cutting-edge technology. Since
            our inception, we've stayed true to our mission, constantly
            evolving and adapting to meet the ever-changing needs of our
            valued customers.At the heart of our business is a team of
            dedicated professionals who strive to exceed your expectations
            every step of the way. From our customer support specialists who
            are always ready to assist you with any inquiries to our logistics
            experts who ensure that your orders are delivered swiftly and
            securely, each member of our team plays a crucial role in making
            your shopping experience truly unforgettable.As we continue to
            grow and expand our offerings, our commitment to customer
            satisfaction remains unwavering. Whether you're browsing our
            website from the comfort of your home or on the go with our mobile
            app, we invite you to explore our extensive selection, discover
            new favorites, and experience the [Your E-Commerce Brand]
            difference for yourself.
          </p>
        </div>
        <img
          src={company}
          className="col-md-6 float-md-end mb-3 ms-md-3 companyimg"
          alt="..."
        />
      </div>
    </section>
    <section className="blog-section">
      <div className="blogcontainer">
        <div className="blogs">
          <div className="blogtitle">
            <h2>blogs and news</h2>
            {/* <p>
      Explore our blog for insightful articles, personal reflections,
      impactful resources, and ideas that inspire us at food on
    </p> */}
          </div>
          <div className="blogcards">
            <div className="blogcard">
              <div className="image-section">
                <img src="images/blog4.jpg" alt="" />
              </div>
              <div className="blogcontent">
                <h4>quality food</h4>
                <p>
                  India’s food culture is more than just a taste of the
                  diverse cuisines that our nation has to offer. It’s a way of
                  life that brings people together, celebrates our traditions,
                  and creates memories that last for a lifetime. As someone
                  born and raised in Meerut, I remember the times when my
                  father would take me on the back of his scooter to Pinki
                  Chole Bhature, one of the town’s most sought-after eateries.
                  The aroma of the spices, the sizzling of the chole and the
                  crispy texture of the bhature made my mouth water with
                  anticipation.
                </p>
              </div>
              <div className="posted-date">
                <p>posted on 18 october 2018</p>
              </div>
            </div>
            <div className="blogcard">
              <div className="image-section">
                <img src={blog_3} alt="" />
              </div>
              <div className="blogcontent">
                <h4>happy customers</h4>
                <p>
                  chose our restaurant as the backdrop for a momentous
                  occasion – his surprise proposal to his girlfriend, Sarah.
                  With the help of our staff, James orchestrated a romantic
                  dinner complete with candlelight and champagne. Sarah said
                  yes, and we were honored to be a part of their unforgettable
                  moment. These heartwarming experiences are a testament to
                  the joy that good food and warm hospitality can bring. To
                  all our wonderful customers, thank you for allowing us to be
                  a part of your special moments.
                </p>
              </div>
              <div className="posted-date">
                <p>posted on 18 october 2018</p>
              </div>
            </div>
            <div className="blogcard">
              <div className="image-section">
                <img src={blog_2} alt="" />
              </div>
              <div className="blogcontent">
                <h4>introducing ai technology</h4>
                <p>
                  AI technology is transforming the way businesses interact
                  with their customers, providing personalized experiences
                  tailored to individual preferences and behaviors. Chatbots
                  and virtual assistants powered by AI algorithms can handle
                  customer inquiries and provide real-time support, improving
                  response times and customer satisfaction. AI-driven
                  recommendation engines analyze user data to offer
                  personalized product suggestions, driving sales and
                  enhancing the overall shopping experience.
                </p>
              </div>
              <div className="posted-date">
                <p>posted on 18 october 2018</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
    <section className="image-gallery">
      <div className="glimpses">
        <h2 className="section-heading">Glimpses of our life</h2>
        <div className="imglinks">
          <div className="img-gallery">
            <div className="image-container1">
              <img src={workcult} alt="" />
            </div>
            <div className="image-container2">
              <div className="colimg1">
                <img src={workimg_5} alt="" />
              </div>
              <div className="colimg2">
                <img src={workimg} alt="" />
              </div>
            </div>
          </div>
          <div className="img-gallery">
            <div className="image-container2">
              <div className="colimg1">
                <img src={workimg_3} alt="" />
              </div>
              <div className="colimg2">
                <img src={workimg_2} alt="" />
              </div>
            </div>
            <div className="image-container3">
              <img src={workimg_7} alt="" />
            </div>
          </div>
        </div>
      </div>
    </section>
    <section className="teamsection">
      <div className="section-header">
        <h2 className="section-headings">meet our team</h2>
        <div className="team-wrapper">
          <div className="team-card">
            <img src={image_1} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">Chandler Bing</h3>
              <h4 className="position">lead developer</h4>
              <p>
                I joined the comapny as lead developer 5 year ago and working
                here is worth experience from learning textual question to
                pracatical expereince of corporate was amazing I was asked to
                face an even bigger challenge by leading restaurant . At a
                time when the threat of COVID was having a detrimental effect
                on the restaurant dining industry, this was an even tougher
                role than I had imagined. .
              </p>
            </div>
          </div>
          <div className="team-card">
            <img src={image_2} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">rachel green</h3>
              <h4 className="position">lead tester</h4>
              <p>
                I started my Zomato journey as tester. Over the last 7 years,
                I have had the privilege of being a part of several teams and
                products, and interacting with many talented individuals,
                helping me learn most of everything I know today.
              </p>
            </div>
          </div>
          <div className="team-card">
            <img src={image_3} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">John Doe</h3>
              <h4 className="position">Tech lead</h4>
              <p>
                Working with this organization is like dream come true.
                working as as tech lead and managing the overall product and
                implement the a product in real time. The people, the energy,
                the feeling of belonging, and the knowledge that I am
                contributing to people’s lives in some way make me want to
                keep being a part of this family. I love solving problems and
                it’s great.
              </p>
            </div>
          </div>
          <div className="team-card">
            <img src={image_4} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">Monica Bing</h3>
              <h4 className="position">Technical Manager</h4>
              <p>
                I joined in 2015 as Manager. Since it was . But here I am, 7
                years and counting, yet only 1% done. I currently work in
                sentiment analysis to check the pulse of the nation. We listen
                to what people say about us and share the same internally, so
                we can address issues, take in recommendations, and deliver
                better experiences.
              </p>
            </div>
          </div>
          <div className="team-card">
            <img src={image_5} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">Divya Sahsani</h3>
              <h4 className="position">Sr.Developer</h4>
              <p>
                I joined this organization as Junior developer and gaining the
                expereince of 1 year my positiion updated to Sr developer.
                this organization helps to understand the indian market very
                easily and help to gain knowledge of practical infromation
                products, and interacting with many talented individuals,
                helping me learn most of everything I know today.
              </p>
            </div>
          </div>
          <div className="team-card">
            <img src={image_6} alt="" className="team" />
            <div className="team-content">
              <h3 className="team-name">Harsh Ahuja</h3>
              <h4 className="position">Technical Manager</h4>
              <p>
                Since my school days, I've always been fond of
                problem-solving. This, combined with my fondness for
                mathematics drove me to software engineering. I joined this
                organization as intern and by acquiring the knowledge of the
                indian market,target audeince working with investors and
                implementing the new technology.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  </>
  )
}
