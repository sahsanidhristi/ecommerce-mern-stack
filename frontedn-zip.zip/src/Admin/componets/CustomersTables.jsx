import React from 'react'

export default function CustomersTable() {
  return (
    <div>CustomersTable</div>
  )
}
