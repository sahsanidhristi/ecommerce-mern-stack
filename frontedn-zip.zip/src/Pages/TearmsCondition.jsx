import React from 'react'

const TearmsCondition = () => {
  return (
    <div>TearmsCondition</div>
  )
}

export default TearmsCondition