import React from 'react'

export default function CreatingProductsForm() {
  return (
    <div>CreatingProductsForm</div>
  )
}
